# Sistema de Almoxarifado

Aplicação web criada do zero para controle de insumos. Implementa autenticação, perfis de Operador e Administrador, cadastro de produtos, entradas e saídas, atualização automática do saldo, bloqueio de estoque negativo, paginação, filtros e rastreabilidade completa.

## Como executar

Requisito: Python 3.10 ou superior. O projeto usa somente a biblioteca padrão e não requer instalação de pacotes.

```bash
python3 run.py
```

Abra `http://127.0.0.1:8000`.

- E-mail inicial: `admin@example.com`
- Senha inicial: `Admin@123`

Altere as credenciais antes do primeiro uso real:

```bash
ALMOX_ADMIN_EMAIL=seu-email@empresa.com \
ALMOX_ADMIN_PASSWORD='uma-senha-forte' \
python3 run.py
```

As variáveis só definem o primeiro administrador quando o banco ainda está vazio. O banco fica em `data/almoxarifado.db`.

## Perfis e regras

- Operador: consulta, cadastra e atualiza produtos; registra entradas e saídas.
- Administrador: possui as permissões do operador e também gerencia usuários e exclusões.
- Toda rota, exceto login e arquivos da interface, exige token de sessão.
- Senhas são armazenadas com PBKDF2 SHA-256, salt aleatório e 310 mil iterações.
- A baixa de estoque ocorre em transação `BEGIN IMMEDIATE`. Uma saída acima do saldo é recusada sem alterar o produto e sem criar histórico.
- Cada movimentação registra data e hora UTC, responsável, saldo anterior e saldo posterior.

## Estrutura

```text
app/
  config.py       configurações por variáveis de ambiente
  db.py           esquema SQLite e inicialização
  security.py     hash de senha e tokens de sessão
  services.py     regras de negócio e transações
  server.py       API HTTP e arquivos estáticos
  static/         interface responsiva
tests/            testes automatizados
docs/             plano e resultados dos testes
```

Essa separação segue uma arquitetura em camadas: apresentação, aplicação/regras de negócio, segurança e persistência.

## API principal

| Método | Rota | Finalidade |
|---|---|---|
| POST | `/api/login` | Autenticar |
| GET | `/api/me` | Obter usuário atual |
| GET e POST | `/api/products` | Listar e cadastrar produtos |
| PATCH e DELETE | `/api/products/{id}` | Atualizar ou excluir produto |
| GET e POST | `/api/movements` | Listar e registrar movimentações |
| GET e POST | `/api/users` | Listar e cadastrar usuários administrativamente |
| PATCH e DELETE | `/api/users/{id}` | Alterar ou excluir usuário administrativamente |

Na listagem de produtos, use `page`, `size`, `name` e `date`. Na listagem de movimentações, use `page`, `size` e `date`.

## Testes

```bash
python3 -m unittest -v
```

Os cinco testes incluem os três cenários obrigatórios de saída: quantidade maior, igual e menor que o saldo. Os documentos em `docs/` apresentam o plano, os dados usados, as saídas obtidas e a conclusão.

## Versionamento sugerido

```bash
git init
git add .
git commit -m "feat: implementa sistema de almoxarifado"
git branch -M seu-nome-sobrenome
```

Depois, configure o repositório remoto e abra um pull request dessa branch para a principal.

