import tempfile
import unittest
from pathlib import Path

from app.db import connect, initialize
from app.services import AppError, CurrentUser, InventoryService


class InventoryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.db = connect(Path(self.temp.name) / "test.db")
        initialize(self.db, "Admin", "admin@test.local", "Admin@123")
        self.service = InventoryService(self.db)
        admin = self.db.execute("SELECT * FROM users WHERE email = 'admin@test.local'").fetchone()
        self.admin = CurrentUser(admin["id"], admin["name"], admin["email"], admin["role"])
        self.product = self.service.create_product({"name": "Detergente", "unit": "un", "quantity": 10})

    def tearDown(self):
        self.db.close()
        self.temp.cleanup()

    def test_cenario_1_bloqueia_saida_acima_do_saldo(self):
        with self.assertRaises(AppError) as context:
            self.service.register_movement(self.admin, self.product["id"], "EXIT", 11)
        self.assertEqual(context.exception.status, 409)
        self.assertEqual(context.exception.message, "Saída não permitida: estoque insuficiente. Disponível: 10. Solicitado: 11.")
        saldo = self.db.execute("SELECT quantity FROM products WHERE id = ?", (self.product["id"],)).fetchone()[0]
        self.assertEqual(saldo, 10)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM movements").fetchone()[0], 0)

    def test_cenario_2_registra_saida_igual_ao_saldo(self):
        movement = self.service.register_movement(self.admin, self.product["id"], "EXIT", 10)
        self.assertEqual(movement["previous_balance"], 10)
        self.assertEqual(movement["new_balance"], 0)
        self.assertEqual(movement["user_name"], "Admin")
        self.assertTrue(movement["created_at"].endswith("Z"))

    def test_cenario_3_registra_saida_menor_que_o_saldo(self):
        movement = self.service.register_movement(self.admin, self.product["id"], "EXIT", 4)
        self.assertEqual(movement["new_balance"], 6)
        product = self.service.list_products(name="deter")["items"][0]
        self.assertEqual(product["quantity"], 6)

    def test_operador_nao_exclui_produto(self):
        operator = CurrentUser(99, "Operador", "op@test.local", "OPERATOR")
        with self.assertRaises(AppError) as context:
            self.service.delete_product(operator, self.product["id"])
        self.assertEqual(context.exception.status, 403)

    def test_paginacao_e_filtro_por_nome(self):
        for i in range(15):
            self.service.create_product({"name": f"Papel {i:02d}"})
        page = self.service.list_products(page=2, size=5, name="Papel")
        self.assertEqual(page["total"], 15)
        self.assertEqual(page["pages"], 3)
        self.assertEqual(len(page["items"]), 5)


if __name__ == "__main__":
    unittest.main()

