from dataclasses import dataclass
import os
from pathlib import Path


@dataclass(frozen=True)
class Config:
    database_path: Path
    host: str = "127.0.0.1"
    port: int = 8000
    session_hours: int = 12
    bootstrap_name: str = "Administrador"
    bootstrap_email: str = "admin@example.com"
    bootstrap_password: str = "Admin@123"

    @classmethod
    def from_env(cls) -> "Config":
        root = Path(__file__).resolve().parent.parent
        return cls(
            database_path=Path(os.getenv("ALMOX_DB", root / "data" / "almoxarifado.db")),
            host=os.getenv("ALMOX_HOST", "127.0.0.1"),
            port=int(os.getenv("ALMOX_PORT", "8000")),
            session_hours=int(os.getenv("ALMOX_SESSION_HOURS", "12")),
            bootstrap_name=os.getenv("ALMOX_ADMIN_NAME", "Administrador"),
            bootstrap_email=os.getenv("ALMOX_ADMIN_EMAIL", "admin@example.com"),
            bootstrap_password=os.getenv("ALMOX_ADMIN_PASSWORD", "Admin@123"),
        )

