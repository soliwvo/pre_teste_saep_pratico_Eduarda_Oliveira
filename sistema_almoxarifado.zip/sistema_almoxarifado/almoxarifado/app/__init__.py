"""Sistema Almoxarifado."""

