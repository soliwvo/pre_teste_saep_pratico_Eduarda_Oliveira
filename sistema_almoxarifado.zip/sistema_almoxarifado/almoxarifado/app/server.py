from __future__ import annotations

import json
import mimetypes
import re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .config import Config
from .db import connect, initialize
from .services import AppError, CurrentUser, InventoryService


STATIC_DIR = Path(__file__).resolve().parent / "static"


class Application:
    def __init__(self, config: Config):
        self.config = config
        bootstrap = connect(config.database_path)
        initialize(bootstrap, config.bootstrap_name, config.bootstrap_email, config.bootstrap_password)
        bootstrap.close()

    def service(self) -> tuple[InventoryService, object]:
        connection = connect(self.config.database_path)
        return InventoryService(connection, self.config.session_hours), connection


class Handler(BaseHTTPRequestHandler):
    server_version = "Almoxarifado/1.0"

    def log_message(self, fmt: str, *args: object) -> None:
        print(f"[{self.log_date_time_string()}] {fmt % args}")

    def _json(self, status: int, data: object) -> None:
        body = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.end_headers()
        self.wfile.write(body)

    def _body(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        if length > 1_000_000:
            raise AppError("Corpo da requisição muito grande.", 413)
        try:
            return json.loads(self.rfile.read(length) or b"{}")
        except json.JSONDecodeError as error:
            raise AppError("JSON inválido.") from error

    def _token(self) -> str | None:
        auth = self.headers.get("Authorization", "")
        return auth[7:] if auth.startswith("Bearer ") else None

    def _serve_static(self, path: str) -> None:
        relative = "index.html" if path in {"/", "/index.html"} else path.removeprefix("/")
        target = (STATIC_DIR / relative).resolve()
        if STATIC_DIR not in target.parents or not target.is_file():
            self._json(404, {"error": "Recurso não encontrado."})
            return
        body = target.read_bytes()
        content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        self.send_response(200)
        self.send_header("Content-Type", f"{content_type}; charset=utf-8" if content_type.startswith("text/") else content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def _dispatch(self, method: str) -> None:
        parsed = urlparse(self.path)
        path, query = parsed.path, parse_qs(parsed.query)
        if not path.startswith("/api/"):
            if method == "GET":
                return self._serve_static(path)
            raise AppError("Método não permitido.", 405)
        service, connection = self.server.application.service()
        try:
            if path == "/api/login" and method == "POST":
                data = self._body()
                return self._json(200, service.login(str(data.get("email", "")), str(data.get("password", ""))))
            current = service.authenticate(self._token())
            if path == "/api/me" and method == "GET":
                return self._json(200, current.__dict__)
            if path == "/api/logout" and method == "POST":
                service.logout(self._token() or "")
                return self._json(204, {})
            if path == "/api/users":
                if method == "GET":
                    return self._json(200, service.list_users(current))
                if method == "POST":
                    return self._json(201, service.create_user(current, self._body()))
            match = re.fullmatch(r"/api/users/(\d+)", path)
            if match:
                user_id = int(match.group(1))
                if method == "PATCH":
                    return self._json(200, service.update_user(current, user_id, self._body()))
                if method == "DELETE":
                    service.delete_user(current, user_id)
                    return self._json(204, {})
            if path == "/api/products":
                if method == "GET":
                    data = service.list_products(int(query.get("page", [1])[0]), int(query.get("size", [10])[0]), query.get("name", [""])[0], query.get("date", [""])[0])
                    return self._json(200, data)
                if method == "POST":
                    return self._json(201, service.create_product(self._body()))
            match = re.fullmatch(r"/api/products/(\d+)", path)
            if match:
                product_id = int(match.group(1))
                if method == "PATCH":
                    return self._json(200, service.update_product(product_id, self._body()))
                if method == "DELETE":
                    service.delete_product(current, product_id)
                    return self._json(204, {})
            if path == "/api/movements":
                if method == "GET":
                    data = service.list_movements(int(query.get("page", [1])[0]), int(query.get("size", [20])[0]), query.get("date", [""])[0])
                    return self._json(200, data)
                if method == "POST":
                    data = self._body()
                    return self._json(201, service.register_movement(current, int(data.get("product_id", 0)), str(data.get("type", "")), int(data.get("quantity", 0))))
            raise AppError("Rota não encontrada.", 404)
        finally:
            connection.close()

    def _handle(self, method: str) -> None:
        try:
            self._dispatch(method)
        except AppError as error:
            self._json(error.status, {"error": error.message})
        except (ValueError, TypeError):
            self._json(400, {"error": "Parâmetros inválidos."})
        except Exception as error:
            print(f"Erro interno: {error!r}")
            self._json(500, {"error": "Erro interno do servidor."})

    def do_GET(self) -> None:
        self._handle("GET")

    def do_POST(self) -> None:
        self._handle("POST")

    def do_PATCH(self) -> None:
        self._handle("PATCH")

    def do_DELETE(self) -> None:
        self._handle("DELETE")


def run(config: Config | None = None) -> None:
    config = config or Config.from_env()
    application = Application(config)
    server = ThreadingHTTPServer((config.host, config.port), Handler)
    server.application = application
    print(f"Sistema de Almoxarifado em http://{config.host}:{config.port}")
    print(f"Administrador inicial: {config.bootstrap_email}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    run()

