from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

from .security import hash_password, hash_token, new_token, verify_password


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


class AppError(Exception):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.message = message
        self.status = status


@dataclass(frozen=True)
class CurrentUser:
    id: int
    name: str
    email: str
    role: str


class InventoryService:
    def __init__(self, connection: sqlite3.Connection, session_hours: int = 12):
        self.db = connection
        self.session_hours = session_hours

    @staticmethod
    def _user(row: sqlite3.Row) -> dict[str, Any]:
        return {
            "id": row["id"], "name": row["name"], "email": row["email"],
            "role": row["role"], "active": bool(row["active"]), "created_at": row["created_at"],
        }

    @staticmethod
    def _require_admin(user: CurrentUser) -> None:
        if user.role != "ADMIN":
            raise AppError("Acesso permitido somente ao administrador.", 403)

    def login(self, email: str, password: str) -> dict[str, Any]:
        row = self.db.execute(
            "SELECT * FROM users WHERE email = ? AND active = 1", (email.strip().lower(),)
        ).fetchone()
        if not row or not verify_password(password, row["password_hash"]):
            raise AppError("E-mail ou senha inválidos.", 401)
        token = new_token()
        created = datetime.now(timezone.utc).replace(microsecond=0)
        expires = created + timedelta(hours=self.session_hours)
        self.db.execute("DELETE FROM sessions WHERE expires_at <= ?", (now_iso(),))
        self.db.execute(
            "INSERT INTO sessions (token_hash, user_id, expires_at, created_at) VALUES (?, ?, ?, ?)",
            (hash_token(token), row["id"], expires.isoformat().replace("+00:00", "Z"), created.isoformat().replace("+00:00", "Z")),
        )
        return {"token": token, "user": self._user(row)}

    def authenticate(self, token: str | None) -> CurrentUser:
        if not token:
            raise AppError("Autenticação obrigatória.", 401)
        row = self.db.execute(
            "SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id "
            "WHERE s.token_hash = ? AND s.expires_at > ? AND u.active = 1",
            (hash_token(token), now_iso()),
        ).fetchone()
        if not row:
            raise AppError("Sessão inválida ou expirada.", 401)
        return CurrentUser(row["id"], row["name"], row["email"], row["role"])

    def logout(self, token: str) -> None:
        self.db.execute("DELETE FROM sessions WHERE token_hash = ?", (hash_token(token),))

    def list_users(self, current: CurrentUser) -> list[dict[str, Any]]:
        self._require_admin(current)
        return [self._user(row) for row in self.db.execute("SELECT * FROM users ORDER BY name")]

    def create_user(self, current: CurrentUser, payload: dict[str, Any]) -> dict[str, Any]:
        self._require_admin(current)
        name = str(payload.get("name", "")).strip()
        email = str(payload.get("email", "")).strip().lower()
        role = str(payload.get("role", "OPERATOR")).upper()
        if not name or "@" not in email or role not in {"OPERATOR", "ADMIN"}:
            raise AppError("Nome, e-mail válido e perfil são obrigatórios.")
        try:
            cursor = self.db.execute(
                "INSERT INTO users (name, email, password_hash, role, active, created_at) VALUES (?, ?, ?, ?, 1, ?)",
                (name, email, hash_password(str(payload.get("password", ""))), role, now_iso()),
            )
        except sqlite3.IntegrityError as error:
            raise AppError("Já existe um usuário com este e-mail.", 409) from error
        return self._user(self.db.execute("SELECT * FROM users WHERE id = ?", (cursor.lastrowid,)).fetchone())

    def update_user(self, current: CurrentUser, user_id: int, payload: dict[str, Any]) -> dict[str, Any]:
        self._require_admin(current)
        row = self.db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        if not row:
            raise AppError("Usuário não encontrado.", 404)
        name = str(payload.get("name", row["name"])).strip()
        email = str(payload.get("email", row["email"])).strip().lower()
        role = str(payload.get("role", row["role"])).upper()
        active = 1 if payload.get("active", bool(row["active"])) else 0
        if not name or "@" not in email or role not in {"OPERATOR", "ADMIN"}:
            raise AppError("Dados do usuário inválidos.")
        if user_id == current.id and (role != "ADMIN" or not active):
            raise AppError("O administrador não pode retirar o próprio acesso.")
        try:
            self.db.execute("UPDATE users SET name = ?, email = ?, role = ?, active = ? WHERE id = ?", (name, email, role, active, user_id))
            if payload.get("password"):
                self.db.execute("UPDATE users SET password_hash = ? WHERE id = ?", (hash_password(str(payload["password"])), user_id))
        except sqlite3.IntegrityError as error:
            raise AppError("Já existe um usuário com este e-mail.", 409) from error
        return self._user(self.db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone())

    def delete_user(self, current: CurrentUser, user_id: int) -> None:
        self._require_admin(current)
        if user_id == current.id:
            raise AppError("O administrador não pode excluir a própria conta.")
        try:
            cursor = self.db.execute("DELETE FROM users WHERE id = ?", (user_id,))
        except sqlite3.IntegrityError as error:
            raise AppError("Usuário possui movimentações e não pode ser excluído. Desative-o.", 409) from error
        if not cursor.rowcount:
            raise AppError("Usuário não encontrado.", 404)

    def list_products(self, page: int = 1, size: int = 10, name: str = "", date: str = "") -> dict[str, Any]:
        page, size = max(1, page), min(100, max(1, size))
        conditions, params = [], []
        if name:
            conditions.append("name LIKE ? COLLATE NOCASE")
            params.append(f"%{name.strip()}%")
        if date:
            conditions.append("substr(updated_at, 1, 10) = ?")
            params.append(date)
        where = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        total = self.db.execute(f"SELECT COUNT(*) FROM products {where}", params).fetchone()[0]
        rows = self.db.execute(
            f"SELECT * FROM products {where} ORDER BY name LIMIT ? OFFSET ?",
            (*params, size, (page - 1) * size),
        ).fetchall()
        return {"items": [dict(row) for row in rows], "page": page, "size": size, "total": total, "pages": (total + size - 1) // size}

    def create_product(self, payload: dict[str, Any]) -> dict[str, Any]:
        name = str(payload.get("name", "")).strip()
        if not name:
            raise AppError("Nome do produto é obrigatório.")
        initial = int(payload.get("quantity", 0))
        if initial < 0:
            raise AppError("O saldo inicial não pode ser negativo.")
        stamp = now_iso()
        cursor = self.db.execute(
            "INSERT INTO products (name, description, unit, quantity, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
            (name, str(payload.get("description", "")).strip(), str(payload.get("unit", "un")).strip() or "un", initial, stamp, stamp),
        )
        return dict(self.db.execute("SELECT * FROM products WHERE id = ?", (cursor.lastrowid,)).fetchone())

    def update_product(self, product_id: int, payload: dict[str, Any]) -> dict[str, Any]:
        row = self.db.execute("SELECT * FROM products WHERE id = ?", (product_id,)).fetchone()
        if not row:
            raise AppError("Produto não encontrado.", 404)
        name = str(payload.get("name", row["name"])).strip()
        if not name:
            raise AppError("Nome do produto é obrigatório.")
        self.db.execute(
            "UPDATE products SET name = ?, description = ?, unit = ?, updated_at = ? WHERE id = ?",
            (name, str(payload.get("description", row["description"])).strip(), str(payload.get("unit", row["unit"])).strip() or "un", now_iso(), product_id),
        )
        return dict(self.db.execute("SELECT * FROM products WHERE id = ?", (product_id,)).fetchone())

    def delete_product(self, current: CurrentUser, product_id: int) -> None:
        self._require_admin(current)
        try:
            cursor = self.db.execute("DELETE FROM products WHERE id = ?", (product_id,))
        except sqlite3.IntegrityError as error:
            raise AppError("Produto possui movimentações e não pode ser excluído.", 409) from error
        if not cursor.rowcount:
            raise AppError("Produto não encontrado.", 404)

    def register_movement(self, current: CurrentUser, product_id: int, movement_type: str, quantity: int) -> dict[str, Any]:
        movement_type = movement_type.upper()
        if movement_type not in {"ENTRY", "EXIT"} or quantity <= 0:
            raise AppError("Tipo e quantidade da movimentação são inválidos.")
        self.db.execute("BEGIN IMMEDIATE")
        try:
            product = self.db.execute("SELECT * FROM products WHERE id = ?", (product_id,)).fetchone()
            if not product:
                raise AppError("Produto não encontrado.", 404)
            previous = product["quantity"]
            if movement_type == "EXIT" and quantity > previous:
                raise AppError(f"Saída não permitida: estoque insuficiente. Disponível: {previous}. Solicitado: {quantity}.", 409)
            new_balance = previous + quantity if movement_type == "ENTRY" else previous - quantity
            stamp = now_iso()
            self.db.execute("UPDATE products SET quantity = ?, updated_at = ? WHERE id = ?", (new_balance, stamp, product_id))
            cursor = self.db.execute(
                "INSERT INTO movements (product_id, movement_type, quantity, previous_balance, new_balance, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (product_id, movement_type, quantity, previous, new_balance, current.id, stamp),
            )
            self.db.execute("COMMIT")
        except Exception:
            if self.db.in_transaction:
                self.db.execute("ROLLBACK")
            raise
        return dict(self.db.execute(
            "SELECT m.*, p.name AS product_name, u.name AS user_name FROM movements m "
            "JOIN products p ON p.id = m.product_id JOIN users u ON u.id = m.user_id WHERE m.id = ?",
            (cursor.lastrowid,),
        ).fetchone())

    def list_movements(self, page: int = 1, size: int = 20, date: str = "") -> dict[str, Any]:
        page, size = max(1, page), min(100, max(1, size))
        where, params = ("WHERE substr(m.created_at, 1, 10) = ?", [date]) if date else ("", [])
        total = self.db.execute(f"SELECT COUNT(*) FROM movements m {where}", params).fetchone()[0]
        rows = self.db.execute(
            f"SELECT m.*, p.name AS product_name, u.name AS user_name FROM movements m "
            f"JOIN products p ON p.id = m.product_id JOIN users u ON u.id = m.user_id {where} "
            "ORDER BY m.id DESC LIMIT ? OFFSET ?", (*params, size, (page - 1) * size)
        ).fetchall()
        return {"items": [dict(row) for row in rows], "page": page, "size": size, "total": total, "pages": (total + size - 1) // size}

